package com.liferay.training.gradebook.web.constants;

/**
 * @author hgrahul
 */
public class GradebookPortletKeys {
	public static final String PORTLET_NAME = "com_liferay_training_gradebook_web_portlet_GradebookPortlet";
}